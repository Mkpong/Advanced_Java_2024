package kr.ac.dankook.ace.hello.lab0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab0Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab0Application.class, args);
	}

}
